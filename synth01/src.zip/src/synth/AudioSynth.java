package synth;

import javax.swing.*;	
import java.awt.*;
import java.awt.event.*;
import javax.sound.sampled.*;
import java.io.*;
import java.nio.channels.*;
import java.nio.*;
import java.util.*;

public class AudioSynth extends JFrame{

  //criar sourceDataLine (saida de audio)
  AudioFormat audioFormat;
  AudioInputStream audioInputStream;
  SourceDataLine sourceDataLine;

  //parametros de audio
  float sampleRate = 16000.0F; //pode ser 8000,11025,16000,22050,44100
  
  int sampleSizeInBits = 16; //pode ser 8,16
  
  int channels = 1;  //pode ser 1,2
  
  boolean signed = true;  //pode ser true,false
  
  boolean bigEndian = true;  //pode ser true,false

  //vetor com 32 tipos de sons (pensando em 32 teclas de teclado)
  //16000 samples por segundo, aguenta 1 segundo stereo e 2 mono
  //nao sei pq * 4, eu sei q stereo duplica a quantidade de bytes
  //mas anyway, copiei isso ai e funcionou
  byte audioData[][] = new byte[32][4000];

  
  //gui whatever
  final JButton generateBtn =
                         new JButton("Generate");
  final JButton playOrFileBtn =
                        new JButton("Play/File");
  final JLabel elapsedTimeMeter =
                              new JLabel("0000");

  final JRadioButton tones =
                  new JRadioButton("Tones",true);

  final JRadioButton listen =
                 new JRadioButton("Listen",true);
  final JRadioButton file =
                        new JRadioButton("File");
  final JTextField fileName =
                       new JTextField("junk",10);


  public AudioSynth(){//constructor
    // etched border.
    final JPanel controlButtonPanel =
                                    new JPanel();
    controlButtonPanel.setBorder(
             BorderFactory.createEtchedBorder());

    //A panel and button group for the radio
    // buttons in the Center position.
    final JPanel synButtonPanel = new JPanel();
    final ButtonGroup synButtonGroup =
                               new ButtonGroup();
    //This panel is used for cosmetic purposes
    // only, to cause the radio buttons to be
    // centered horizontally in the Center
    // position.
    final JPanel centerPanel = new JPanel();

    //A panel for the South position.  Note the
    // etched border.
    final JPanel outputButtonPanel =
                                    new JPanel();
    outputButtonPanel.setBorder(
             BorderFactory.createEtchedBorder());
    final ButtonGroup outputButtonGroup =
                               new ButtonGroup();

    //Disable the Play button initially to force
    // the user to generate some data before
    // trying to listen to it or write it to a
    // file.
    playOrFileBtn.setEnabled(false);

    //Register anonymous listeners on the
    // Generate button and the Play/File button.
    generateBtn.addActionListener(
      new ActionListener(){
        public void actionPerformed(
                                  ActionEvent e){
          //Don't allow Play during generation
          playOrFileBtn.setEnabled(false);
          
          
          //AQUI DA O LOAD DAS TECLAS, VOU TRABALHAR AQUI
          //  E ELE RETORNARA O VETOR COM TUDO BONITINHO
          new SynGen().getSyntheticData(
                                      audioData);
          
          //Now it is OK for the user to listen
          // to or file the synthetic audio data.
          playOrFileBtn.setEnabled(true);
        }//end actionPerformed
      }//end ActionListener
    );//end addActionListener()

    playOrFileBtn.addActionListener(
      new ActionListener(){
        public void actionPerformed(
                                  ActionEvent e){
          //Play or file the data synthetic data
          playNote(0);
        }//end actionPerformed
      }//end ActionListener
    );//end addActionListener()

    //Add two buttons and a text field to a
    // physical group in the North of the GUI.
    controlButtonPanel.add(generateBtn);
    controlButtonPanel.add(playOrFileBtn);
    controlButtonPanel.add(elapsedTimeMeter);

    //Add radio buttons to a mutually exclusive
    // group in the Center of the GUI.  Make
    // additions here if you add new synthetic
    // generator methods.
    synButtonGroup.add(tones);

    //Add radio buttons to a physical group and
    // center it in the Center of the GUI. Make
    // additions here if you add new synthetic
    // generator methods.
    synButtonPanel.setLayout(
                            new GridLayout(0,1));
    synButtonPanel.add(tones);

    //Note that the centerPanel has center
    // alignment by default.
    centerPanel.add(synButtonPanel);

    //Add radio buttons to a mutually exclusive
    // group in the South of the GUI.
    outputButtonGroup.add(listen);
    outputButtonGroup.add(file);

    //Add radio buttons to a physical group in
    // the South of the GUI.
    outputButtonPanel.add(listen);
    outputButtonPanel.add(file);
    outputButtonPanel.add(fileName);

    //Add the panels containing components to the
    // content pane of the GUI in the appropriate
    // positions.
    getContentPane().add(
          controlButtonPanel,BorderLayout.NORTH);
    getContentPane().add(centerPanel,
                            BorderLayout.CENTER);
    getContentPane().add(outputButtonPanel,
                             BorderLayout.SOUTH);

    //Finish the GUI.  If you add more radio
    // buttons in the center, you may need to
    // modify the call to setSize to increase
    // the vertical component of the GUI size.
    setTitle("Copyright 2003, R.G.Baldwin");
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setSize(250,275);
    setVisible(true);
  }//end constructor
  //-------------------------------------------//

  //This method plays or files the synthetic
  // audio data that has been generated and saved
  // in an array in memory.
  public void playNote(int note) {
    try{
      //Get an input stream on the byte array
      // containing the data
      InputStream byteArrayInputStream =
                        new ByteArrayInputStream(
                                      audioData[note]);

      //Get the required audio format
      audioFormat = new AudioFormat(
                                sampleRate,
                                sampleSizeInBits,
                                channels,
                                signed,
                                bigEndian);

      //Get an audio input stream from the
      // ByteArrayInputStream
      audioInputStream = new AudioInputStream(
                    byteArrayInputStream,
                    audioFormat,
                    audioData[0].length/audioFormat.
                                 getFrameSize());

      //Get info on the required data line
      DataLine.Info dataLineInfo =
                          new DataLine.Info(
                            SourceDataLine.class,
                                    audioFormat);

      //Get a SourceDataLine object
      sourceDataLine = (SourceDataLine)
                             AudioSystem.getLine(
                                   dataLineInfo);
      //Decide whether to play the synthetic
      // data immediately, or to write it into
      // an audio file, based on the user
      // selection of the radio buttons in the
      // South of the GUI..
        new ListenThread().start();
    }catch (Exception e) {
      e.printStackTrace();
      System.exit(0);
    }//end catch
  }//end playOrFileData
//=============================================//

//Inner class to play back the data that was
// saved.
class ListenThread extends Thread{
  //This is a working buffer used to transfer
  // the data between the AudioInputStream and
  // the SourceDataLine.  The size is rather
  // arbitrary.
  byte playBuffer[] = new byte[16384];

  public void run(){
    try{
      //Disable buttons while data is being
      // played.
      generateBtn.setEnabled(false);
      playOrFileBtn.setEnabled(false);

      //Open and start the SourceDataLine
      sourceDataLine.open(audioFormat);
      sourceDataLine.start();

      int cnt;
      //Get beginning of elapsed time for
      // playback
      long startTime = new Date().getTime();

      //Transfer the audio data to the speakers
      while((cnt = audioInputStream.read(
                              playBuffer, 0,
                              playBuffer.length))
                                          != -1){
        //Keep looping until the input read
        // method returns -1 for empty stream.
        if(cnt > 0){
          //Write data to the internal buffer of
          // the data line where it will be
          // delivered to the speakers in real
          // time
          sourceDataLine.write(
                             playBuffer, 0, cnt);
        }//end if
      }//end while

      //Block and wait for internal buffer of the
      // SourceDataLine to become empty.
      sourceDataLine.drain();


      //Get and display the elapsed time for
      // the previous playback.
      int elapsedTime =
         (int)(new Date().getTime() - startTime);
      elapsedTimeMeter.setText("" + elapsedTime);

      //Finish with the SourceDataLine
      sourceDataLine.stop();
      sourceDataLine.close();

      //Re-enable buttons for another operation
      generateBtn.setEnabled(true);
      playOrFileBtn.setEnabled(true);
    }catch (Exception e) {
      e.printStackTrace();
      System.exit(0);
    }//end catch

  }//end run
}//end inner class ListenThread
//=============================================//

//Inner signal generator class.

//An object of this class can be used to
// generate a variety of different synthetic
// audio signals.  Each time the getSyntheticData
// method is called on an object of this class,
// the method will fill the incoming array with
// the samples for a synthetic signal.
class SynGen{
  //Note:  Because this class uses a ByteBuffer
  // asShortBuffer to handle the data, it can
  // only be used to generate signed 16-bit
  // data.
  ByteBuffer byteBuffer;
  ShortBuffer shortBuffer;
  int byteLength;

  void getSyntheticData(byte[][] synDataBuffer){
    //Prepare the ByteBuffer and the shortBuffer
    // for use
    byteBuffer = ByteBuffer.wrap(synDataBuffer[0]); //C4
    shortBuffer = byteBuffer.asShortBuffer();
    byteLength = synDataBuffer[0].length;
    tones(shortBuffer, 261.63f);
    
    byteBuffer = ByteBuffer.wrap(synDataBuffer[1]); //C#4
    shortBuffer = byteBuffer.asShortBuffer();
    byteLength = synDataBuffer[0].length;
    tones(shortBuffer, 277.18f);
    
    byteBuffer = ByteBuffer.wrap(synDataBuffer[2]); //D4
    shortBuffer = byteBuffer.asShortBuffer();
    byteLength = synDataBuffer[0].length;
    tones(shortBuffer, 293.66f);
    
    byteBuffer = ByteBuffer.wrap(synDataBuffer[3]); //D#4
    shortBuffer = byteBuffer.asShortBuffer();
    byteLength = synDataBuffer[0].length;
    tones(shortBuffer, 311.13f);
    
    byteBuffer = ByteBuffer.wrap(synDataBuffer[4]); //E4
    shortBuffer = byteBuffer.asShortBuffer();
    byteLength = synDataBuffer[0].length;
    tones(shortBuffer, 329.63f);
    
    byteBuffer = ByteBuffer.wrap(synDataBuffer[5]); //F4
    shortBuffer = byteBuffer.asShortBuffer();
    byteLength = synDataBuffer[0].length;
    tones(shortBuffer, 349.23f);
    
    byteBuffer = ByteBuffer.wrap(synDataBuffer[6]); //F#4
    shortBuffer = byteBuffer.asShortBuffer();
    byteLength = synDataBuffer[0].length;
    tones(shortBuffer, 369.99f);
    
    byteBuffer = ByteBuffer.wrap(synDataBuffer[7]); //G5
    shortBuffer = byteBuffer.asShortBuffer();
    byteLength = synDataBuffer[0].length;
    tones(shortBuffer, 392.00f);
    
    byteBuffer = ByteBuffer.wrap(synDataBuffer[8]); //G#5
    shortBuffer = byteBuffer.asShortBuffer();
    byteLength = synDataBuffer[0].length;
    tones(shortBuffer, 415.30f);
    
    byteBuffer = ByteBuffer.wrap(synDataBuffer[9]); //A4
    shortBuffer = byteBuffer.asShortBuffer();
    byteLength = synDataBuffer[0].length;
    tones(shortBuffer, 440.00f);
    
    byteBuffer = ByteBuffer.wrap(synDataBuffer[10]); //A#4
    shortBuffer = byteBuffer.asShortBuffer();
    byteLength = synDataBuffer[0].length;
    tones(shortBuffer, 466.16f);
    
    byteBuffer = ByteBuffer.wrap(synDataBuffer[11]); //B
    shortBuffer = byteBuffer.asShortBuffer();
    byteLength = synDataBuffer[0].length;
    tones(shortBuffer, 493.88f);
    
    byteBuffer = ByteBuffer.wrap(synDataBuffer[12]); //CCBZNMX
    shortBuffer = byteBuffer.asShortBuffer();
    byteLength = synDataBuffer[0].length;
    tones(shortBuffer, 523.25f);

  }
  
  void tones(ShortBuffer shortBuffer,double freq){
    channels = 1;//Java allows 1 or 2
    //Each channel requires two 8-bit bytes per
    // 16-bit sample.
    int bytesPerSamp = 2;
    sampleRate = 16000.0F;
    // Allowable 8000,11025,16000,22050,44100
    int sampLength = byteLength/bytesPerSamp;
    for(int cnt = 0; cnt < sampLength; cnt++){
      double time = cnt/sampleRate;
      double sinValue =
        (Math.sin(2*Math.PI*freq*time));
      shortBuffer.put((short)(16000*sinValue));
    }//end for loop
  }//end method tones
}
}//end outer class AudioSynth01.java
